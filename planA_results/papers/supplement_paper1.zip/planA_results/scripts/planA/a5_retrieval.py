#!/usr/bin/env python3
"""A5: retrieval-mode audit. How often does each retrieval mode surface the gold functions / files?

Modes (per task, query = problem statement):
  (a) harness   : issue identifiers (deterministic extraction) -> swegemma's 4-tier resolve_node_name
                  -> cosine ranking against all nodes (exactly search_similar_code), union over
                  identifiers ranked by best similarity; the resolved anchors themselves count as rank 0
  (a0) anchors  : the resolved anchors alone (what an agent sees before any similarity call)
  (b) bm25      : BM25 over node text (id + text), free-text issue query
  (c) freetext  : issue text embedded with the encoder identified in A3 (``--encoder``), cosine
                  against the provided vectors.  Skipped when no encoder is given.
  (d) harness+1hop : mode (a) plus 1-hop call neighbours of the anchors and of the top-10 hits
  (e) bm25_snapshot: BM25 over every non-test def of the real snapshot source (id + source text),
                  free-text issue query. Independent of the provided graph, so it can hit gold symbols
                  the graph omits (async defs); its gold set is every gold symbol, present or not.
Metrics: gold-node Hit@10 (any gold node in top 10) and gold-file Hit@5 (file = module of a gold
node; a node's module via the same heuristic as A1), MRR, per repo; share of tasks where the mode
returns nothing at all (no identifier resolves).

Denominators: ``overall_tasks_with_gold_nodes`` (tasks with >= 1 gold node in the graph, the original
report) and ``overall_all_tasks`` (all tasks; a task with no gold node counts as a miss for the graph
modes a0/a/b/d, while mode e is scored against every gold symbol). Per repo for both.

Inputs: archive + A1 outputs (a1_gold_symbols.jsonl for gold node ids; a1_tasks.csv not required).
Outputs: a5_tasks.csv, a5_summary.json.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from a1_census import module_of_node  # noqa: E402
from stats import mcnemar, mean_ci, wilson  # noqa: E402
from common import (  # noqa: E402
    BM25, ModuleIndex, Snapshot, extract_identifiers, find_snapshot, flat_identifiers, get_embeddings, get_graph,
    is_test_path, iter_defs, load_tasks, pct, provided_node_id, read_jsonl, resolve_node_name, write_csv,
)


def snapshot_def_docs(snap: Snapshot, mi: ModuleIndex) -> tuple[dict[str, str], dict[str, str]]:
    """Every non-test def of the snapshot as a BM25 document, keyed by its provided-scheme node id.
    Returns (docs, module_of_doc)."""
    files = [f for f in snap.list_files(".py") if not is_test_path(f)]
    texts = snap.read_many(files)
    docs: dict[str, str] = {}
    mod_of: dict[str, str] = {}
    for f in files:
        src = texts.get(f) or ""
        mod, _ = mi.module_for(f, infer=True)
        if mod is None:
            continue
        lines = src.splitlines()
        for d in iter_defs(src):
            nid = provided_node_id(mod, d.qualname)
            body = "\n".join(lines[d.lineno - 1: d.end_lineno])
            docs[nid] = (docs[nid] + "\n" + body) if nid in docs else f"{nid}\n{body}"
            mod_of[nid] = mod
    return docs, mod_of


def rank_metrics(ranked: list[str], gold_nodes: set[str], gold_mods: set[str], mod_of) -> dict:
    hit_node = next((i + 1 for i, n in enumerate(ranked) if n in gold_nodes), None)
    files_seen, hit_file = [], None
    for n in ranked:
        m = mod_of(n)
        if m not in files_seen:
            files_seen.append(m)
            if m in gold_mods and hit_file is None:
                hit_file = len(files_seen)
    return {"node_rank": hit_node, "file_rank": hit_file, "hit10_node": bool(hit_node and hit_node <= 10),
            "hit5_file": bool(hit_file and hit_file <= 5), "n_returned": len(ranked),
            "rr_node": (1 / hit_node) if hit_node else 0.0}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True, type=Path)
    ap.add_argument("--a1", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--encoder", default=None, help="sentence-transformers model id identified by A3 (mode c)")
    ap.add_argument("--encoder-prompt", default="task: code retrieval | query: ")
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--task-ids", nargs="*", default=None)
    ap.add_argument("--cache", type=Path, default=None, help="snapshot extraction cache (mode e)")
    ap.add_argument("--no-snapshot-mode", action="store_true", help="skip mode (e)")
    args = ap.parse_args(argv)
    cache = args.cache or (args.out.parent / "cache")
    args.out.mkdir(parents=True, exist_ok=True)

    gold_by_task: dict[str, set[str]] = defaultdict(set)
    gold_files_by_task: dict[str, set[str]] = defaultdict(set)
    gold_all_by_task: dict[str, set[str]] = defaultdict(set)      # every gold symbol, present or not (mode e)
    for r in read_jsonl(args.a1 / "a1_gold_symbols.jsonl"):
        if r.get("node_id") and r.get("present_in_graph") and not r.get("new_symbol"):
            gold_by_task[r["instance_id"]].add(r["node_id"])
        if r.get("node_id") and r.get("qualname") and not r.get("new_symbol"):
            gold_all_by_task[r["instance_id"]].add(r["node_id"])
        if r.get("module"):
            gold_files_by_task[r["instance_id"]].add(r["module"])

    encoder = None
    if args.encoder:
        from sentence_transformers import SentenceTransformer
        encoder = SentenceTransformer(args.encoder, device="cpu")

    rows = []
    bm_cache: dict[str, BM25] = {}
    snap_cache: dict[str, tuple[BM25, dict[str, str]]] = {}
    for t in load_tasks(args.data, args.task_ids):
        g = get_graph(args.data, t)
        E = get_embeddings(args.data, t)
        gold_nodes = gold_by_task.get(t.instance_id, set())
        if g is None or E is None:
            rows.append({"instance_id": t.instance_id, "repo": t.repo, "skipped": "graph/embeddings missing"})
            continue
        mi = ModuleIndex(g)
        gold_mods = set(gold_files_by_task.get(t.instance_id, set()))
        for f in t.gold_files:
            if f.endswith(".py") and not is_test_path(f):
                m, _ = mi.module_for(f)
                if m:
                    gold_mods.add(m)
        mod_of = lambda n: module_of_node(n, g)  # noqa: E731
        ids = [n for n in g.nodes if n in E]
        idx = {n: i for i, n in enumerate(ids)}
        M = np.stack([E[n] for n in ids]).astype(np.float32)
        M /= np.maximum(np.linalg.norm(M, axis=1, keepdims=True), 1e-9)
        base = {"instance_id": t.instance_id, "repo": t.repo, "n_gold_nodes": len(gold_nodes), "n_gold_modules": len(gold_mods),
                "gold_in_embeddings": sum(1 for x in gold_nodes if x in idx)}

        # (a) harness mode
        toks = flat_identifiers(extract_identifiers(t.problem_statement))
        anchors = []
        for tok in toks:
            nid, tier = resolve_node_name(tok, g.nodes)
            if nid and nid not in anchors:
                anchors.append(nid)
        base["n_identifiers"] = len(toks)
        base["n_anchors"] = len(anchors)
        best: dict[str, float] = {}
        for a in anchors:
            if a not in idx:
                continue
            sims = M @ M[idx[a]]
            order = np.argsort(-sims)
            cnt = 0
            for j in order:
                n = ids[j]
                if n == a:
                    continue
                best[n] = max(best.get(n, -2), float(sims[j]))
                cnt += 1
                if cnt >= args.k:
                    break
        harness_rank = anchors + [n for n, _ in sorted(best.items(), key=lambda kv: -kv[1]) if n not in anchors]
        for name, ranked in (("a0_anchors", anchors), ("a_harness", harness_rank)):
            for k, v in rank_metrics(ranked, gold_nodes, gold_mods, mod_of).items():
                base[f"{name}_{k}"] = v
        # (d) harness + 1 hop
        hop = list(harness_rank)
        for a in anchors + harness_rank[: args.k]:
            for n in sorted(g.neighbors(a)):
                if n not in hop:
                    hop.append(n)
        for k, v in rank_metrics(hop, gold_nodes, gold_mods, mod_of).items():
            base[f"d_harness_1hop_{k}"] = v
        # (b) BM25
        if g.key not in bm_cache:
            bm_cache[g.key] = BM25({n: f"{n}\n{a['text']}" for n, a in g.nodes.items()})
        bm_rank = bm_cache[g.key].rank(t.problem_statement)
        for k, v in rank_metrics(bm_rank, gold_nodes, gold_mods, mod_of).items():
            base[f"b_bm25_{k}"] = v
        # (c) free text embedding
        if encoder is not None:
            q = encoder.encode([args.encoder_prompt + (t.problem_statement or "")], convert_to_numpy=True)[0][: M.shape[1]]
            q = q / (np.linalg.norm(q) or 1)
            order = np.argsort(-(M @ q))
            ft_rank = [ids[j] for j in order]
            for k, v in rank_metrics(ft_rank, gold_nodes, gold_mods, mod_of).items():
                base[f"c_freetext_{k}"] = v
        # (e) BM25 over the snapshot's real source defs
        if not args.no_snapshot_mode:
            if g.key not in snap_cache:
                sp = find_snapshot(args.data, t)
                if sp is not None:
                    docs, snap_mod = snapshot_def_docs(Snapshot(sp, cache, t.instance_id), mi)
                    snap_cache[g.key] = (BM25(docs), snap_mod)
            if g.key in snap_cache:
                bm_s, snap_mod = snap_cache[g.key]
                gold_all = gold_all_by_task.get(t.instance_id, set())
                base["n_gold_symbols_all"] = len(gold_all)
                for k, v in rank_metrics(bm_s.rank(t.problem_statement), gold_all, gold_mods,
                                         lambda n: snap_mod.get(n) or mod_of(n)).items():
                    base[f"e_bm25_snapshot_{k}"] = v
        rows.append(base)
        print(f"[a5] {t.instance_id}: anchors={len(anchors)} a_hit10={base['a_harness_hit10_node']} "
              f"bm25_hit10={base['b_bm25_hit10_node']} 1hop_hit10={base['d_harness_1hop_hit10_node']}", flush=True)

    write_csv(args.out / "a5_tasks.csv", rows)
    modes = (["a0_anchors", "a_harness", "d_harness_1hop", "b_bm25"] + (["c_freetext"] if encoder else [])
             + (["e_bm25_snapshot"] if any("e_bm25_snapshot_hit10_node" in r for r in rows) else []))
    valid = [r for r in rows if "skipped" not in r]
    with_gold = [r for r in valid if r["n_gold_nodes"] > 0]

    def summ(rs):
        out = {}
        for m in modes:
            out[m] = {"hit10_node": wilson(sum(1 for r in rs if r.get(f"{m}_hit10_node")), len(rs)),
                      "hit5_file": wilson(sum(1 for r in rs if r.get(f"{m}_hit5_file")), len(rs)),
                      "mrr_node": mean_ci([r.get(f"{m}_rr_node", 0) for r in rs]),
                      "empty": wilson(sum(1 for r in rs if r.get(f"{m}_n_returned") == 0), len(rs))}
        # paired comparisons on the same tasks (H-A4: symbol-only harness mode vs free text / BM25)
        pairs = [("a_harness", "b_bm25"), ("a_harness", "d_harness_1hop"), ("a0_anchors", "a_harness")]
        if "c_freetext" in modes:
            pairs += [("a_harness", "c_freetext"), ("b_bm25", "c_freetext")]
        if "e_bm25_snapshot" in modes:
            pairs += [("a_harness", "e_bm25_snapshot"), ("b_bm25", "e_bm25_snapshot")]
        out["paired_mcnemar"] = {
            f"{a}_vs_{b}": {metric: mcnemar([bool(r.get(f"{a}_{metric}")) for r in rs], [bool(r.get(f"{b}_{metric}")) for r in rs])
                            for metric in ("hit10_node", "hit5_file")}
            for a, b in pairs}
        return out

    per_repo = defaultdict(list)
    for r in with_gold:
        per_repo[r["repo"]].append(r)
    per_repo_all = defaultdict(list)
    for r in valid:
        per_repo_all[r["repo"]].append(r)
    summary = {"n_tasks": len(rows), "n_valid": len(valid), "n_with_gold_nodes": len(with_gold),
               "tasks_zero_anchors": wilson(sum(1 for r in valid if r["n_anchors"] == 0), len(valid)),
               "overall_tasks_with_gold_nodes": summ(with_gold),
               "overall_all_tasks": summ(valid),
               "per_repo": {k: summ(v) for k, v in per_repo.items()},
               "per_repo_all_tasks": {k: summ(v) for k, v in per_repo_all.items()},
               "note": "overall_tasks_with_gold_nodes: tasks with >=1 gold node present in the graph. "
                       "overall_all_tasks: every task with a graph; graph modes (a0, a, b, d, c) score a miss "
                       "where no gold node exists in the graph; mode e (bm25_snapshot) ranks the real source "
                       "and is scored against every gold symbol, including those the graph omits."}
    (args.out / "a5_summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
